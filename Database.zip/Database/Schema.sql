CREATE DATABASE IF NOT EXISTS parking_system;
USE parking_system;



DROP TABLE IF EXISTS SLOT;
DROP TABLE IF EXISTS VEHICLE;
DROP TABLE IF EXISTS CUSTOMER;
DROP TABLE IF EXISTS FLOOR;



CREATE TABLE FLOOR (
    floorID       INT AUTO_INCREMENT PRIMARY KEY,
    section       VARCHAR(50)   NOT NULL,
    regularPrice  DECIMAL(10,2) NOT NULL,
    discountPrice DECIMAL(10,2) NOT NULL

);



CREATE TABLE CUSTOMER (
    customerID       INT AUTO_INCREMENT PRIMARY KEY,
    customerName     VARCHAR(100) NOT NULL,
    customerContact  VARCHAR(11)  NOT NULL

);



CREATE TABLE VEHICLE (
    vehicleID INT AUTO_INCREMENT PRIMARY KEY,
    plateNo   VARCHAR(7)  NOT NULL,
    carType   VARCHAR(50) NOT NULL,
    isECar    BOOLEAN     NOT NULL DEFAULT FALSE

);



CREATE TABLE SLOT (
    slotID           INT AUTO_INCREMENT PRIMARY KEY,
    floorID          INT NOT NULL,
    customerID       INT DEFAULT NULL,
    vehicleID        INT DEFAULT NULL,
    slotNumber       INT NOT NULL,
    isPWD            BOOLEAN NOT NULL DEFAULT FALSE,
    isECarOnly       BOOLEAN NOT NULL DEFAULT FALSE,
    status           VARCHAR(20) NOT NULL DEFAULT 'Available',
    unit             VARCHAR(50) DEFAULT NULL,
    unitID           VARCHAR(50) DEFAULT NULL,
    rentDuration     INT DEFAULT 0,
    rentDurationUnit VARCHAR(10) DEFAULT NULL,
    amountPaid       DECIMAL(10,2) DEFAULT 0,
    CONSTRAINT fk_slot_floor    FOREIGN KEY (floorID)    REFERENCES FLOOR(floorID),
    CONSTRAINT fk_slot_customer FOREIGN KEY (customerID) REFERENCES CUSTOMER(customerID),
    CONSTRAINT fk_slot_vehicle  FOREIGN KEY (vehicleID)  REFERENCES VEHICLE(vehicleID),
    CONSTRAINT uq_slot_floor_number UNIQUE (floorID, slotNumber)
);



-- Sections + pricing, matching Frontend.buildSampleSystem()
INSERT INTO FLOOR (section, regularPrice, discountPrice) VALUES
('Basement 2',   2200.00, 1800.00),
('Basement 1',   2500.00, 2000.00),
('Ground Floor', 3000.00, 2400.00),
('2nd Floor',    2800.00, 2200.00),
('3rd Floor',    2800.00, 2200.00),
('4th Floor',    2600.00, 2100.00),
('5th Floor',    2600.00, 2100.00);



-- 8 slots per floor: 1-3 = PWD, 4-5 = E-Car only, 6-8 = regular (same layout as buildSampleSystem())
INSERT INTO SLOT (floorID, slotNumber, isPWD, isECarOnly)
SELECT f.floorID, n.slotNumber, n.slotNumber BETWEEN 1 AND 5, n.slotNumber IN (10, 15)
FROM FLOOR f

CROSS JOIN (
    SELECT 1 AS slotNumber UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
    UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8
    UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11 UNION ALL SELECT 12
    UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15 UNION ALL SELECT 16
    UNION ALL SELECT 17 UNION ALL SELECT 18 UNION ALL SELECT 19 UNION ALL SELECT 20

) n; 