package lib;

// mlem, just the vehicle deets
public class Vehicle {
    private int vehicleId = -1; // maps to VEHICLE.vehicleID; -1 = not persisted yet
    private boolean isECar;
    private String plateNo;
    private String carType;

    public Vehicle(String plateNo, String carType, boolean isECar) {
        this.plateNo = plateNo;
        this.carType = carType;
        this.isECar = isECar;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public boolean isECar() {
        return isECar;
    }

    public String getPlateNo() {
        return plateNo;
    }

    public String getCarType() {
        return carType;
    }

    @Override
    public String toString() {
        return carType + " (" + plateNo + ")" + (isECar ? " [E-Car]" : "");
    }
}