package lib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParkingSystem {
    public static final String ALL_SECTIONS = "All Sections";

    // Login!
    public enum Role { CUSTOMER, ADMIN }

    private static class Account {
        final String password;
        final Role role;

        Account(String password, Role role) {
            this.password = password;
            this.role = role;
        }
    }

    private static final Map<String, Account> ACCOUNTS = new HashMap<>();

    static {
        // ADMIN
        ACCOUNTS.put("admin123", new Account("Admin@123", Role.ADMIN));

        // CUSTOMERS
        ACCOUNTS.put("0123456789", new Account("Resident@123", Role.CUSTOMER));
        ACCOUNTS.put("9876543210", new Account("Resident@456", Role.CUSTOMER));
    }

    private List<Floor> floors;

    public ParkingSystem() {
        this.floors = new ArrayList<>();
    }

    // returns the user's Role if the ID and password match
    public Role login(String id, String password) {
        if (id == null || password == null) return null;

        Account account = ACCOUNTS.get(id.trim());
        if (account != null && account.password.equals(password)) {
            return account.role;
        }
        return null;
    }

    public void addFloor(Floor floor) {
        floors.add(floor);
    }

    public List<Floor> getFloors() {
        return floors;
    }

    public Floor getFloorBySection(String section) {
        for (Floor f : floors) {
            if (f.getSection().equalsIgnoreCase(section)) {
                return f;
            }
        }
        return null;
    }


    public boolean isSlotAvailable(String section, int slotNumber) {
        Floor floor = getFloorBySection(section);
        if (floor == null) return false;
        Slot slot = floor.getSlot(slotNumber);
        return slot != null && slot.getStatus().equals(Slot.STATUS_AVAILABLE);
    }

    // displays!
    public double getRate(String section, boolean isPWDSlot, String unit) {
        Floor floor = getFloorBySection(section);
        if (floor == null) return 0.0;
        double monthly = isPWDSlot ? floor.getDiscountPrice() : floor.getRegularPrice();
        if (Floor.UNIT_DAY.equals(unit)) return monthly / 30.0;
        if (Floor.UNIT_WEEK.equals(unit)) return monthly / 4.0;
        return monthly;
    }

  
    public TransactionResult doTransaction(String section, int slotNumber, String customerName,
                                            String customerContact, String unit, String unitId,
                                            int rentDuration, String rentDurationUnit, Vehicle vehicle) {
        Floor floor = getFloorBySection(section);
        if (floor == null) {
            return new TransactionResult(false, "Section not found.", 0.0);
        }

        Slot slot = floor.getSlot(slotNumber);
        if (slot == null) {
            return new TransactionResult(false, "Slot not found.", 0.0);
        }

        if (!slot.getStatus().equals(Slot.STATUS_AVAILABLE)) {
            return new TransactionResult(false, "Slot is not available.", 0.0);
        }

        if (slot.isECarOnly() && (vehicle == null || !vehicle.isECar())) {
            return new TransactionResult(false, "This slot is reserved for E-Cars only.", 0.0);
        }

        if (rentDuration <= 0) {
            return new TransactionResult(false, "Rent duration must be greater than zero.", 0.0);
        }

        double rate = floor.getRateFor(slot, rentDurationUnit);
        double totalAmount = rate * rentDuration;

        slot.sellSlot(customerName, customerContact, unit, unitId, rentDuration, rentDurationUnit,
                totalAmount, vehicle);
                
        // database~
        try {
            ParkingDAO dao = new ParkingDAO();
            dao.saveTransaction(slot, customerName, customerContact, unit, unitId, rentDuration, rentDurationUnit, totalAmount, vehicle);
        } catch (Exception ex) {
            ex.printStackTrace();
            return new TransactionResult(false, "Database Error: Could not save transaction.", 0.0);
        }

        return new TransactionResult(true, "Transaction confirmed.", totalAmount);
    }

    // frees a rented slot again
    public TransactionResult cancelRental(String section, int slotNumber, String cancelledBy) {
        Floor floor = getFloorBySection(section);
        if (floor == null) {
            return new TransactionResult(false, "Section not found.", 0.0);
        }

        Slot slot = floor.getSlot(slotNumber);
        if (slot == null) {
            return new TransactionResult(false, "Slot not found.", 0.0);
        }

        if (!slot.getStatus().equals(Slot.STATUS_SOLD)) {
            return new TransactionResult(false, "This slot is not currently rented.", 0.0);
        }

        try {
            new ParkingDAO().cancelTransaction(slot, floor.getSection(), cancelledBy);
        } catch (Exception ex) {
            ex.printStackTrace();
            return new TransactionResult(false, "Database Error: Could not cancel the rental.", 0.0);
        }

        slot.clearSlot();
        return new TransactionResult(true, "Rental cancelled. Slot " + slotNumber + " is available again.", 0.0);
    }

    // the customers can only send a request, admis are the one who will cancel
    public TransactionResult requestCancellation(String section, int slotNumber) {
        Floor floor = getFloorBySection(section);
        if (floor == null) {
            return new TransactionResult(false, "Section not found.", 0.0);
        }

        Slot slot = floor.getSlot(slotNumber);
        if (slot == null) {
            return new TransactionResult(false, "Slot not found.", 0.0);
        }

        if (!slot.getStatus().equals(Slot.STATUS_SOLD)) {
            return new TransactionResult(false, "This slot is not currently rented.", 0.0);
        }

        if (slot.getSlotId() <= 0) {
            return new TransactionResult(false, "Cancellation requests need the database connection.", 0.0);
        }

        try {
            ParkingDAO dao = new ParkingDAO();
            if (dao.hasPendingRequest(slot)) {
                return new TransactionResult(false,
                        "A cancellation request for this slot is already waiting for an admin.", 0.0);
            }
            dao.saveCancelRequest(slot, floor.getSection());
        } catch (Exception ex) {
            ex.printStackTrace();
            return new TransactionResult(false, "Database Error: Could not send the request.", 0.0);
        }

        return new TransactionResult(true, "Cancellation request sent. An admin will review it.", 0.0);
    }

    // if the admin turns a request down, the rental stays as it is
    public TransactionResult declineCancelRequest(int requestId, String declinedBy) {
        try {
            if (!new ParkingDAO().declineRequest(requestId, declinedBy)) {
                return new TransactionResult(false, "This request was already handled.", 0.0);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return new TransactionResult(false, "Database Error: Could not decline the request.", 0.0);
        }
        return new TransactionResult(true, "Request declined. The rental stays active.", 0.0);
    }

    // full report
    public String generateReport() {
        return generateReport(ALL_SECTIONS);
    }

    public String generateReport(String sectionFilter) {
        boolean allSections = sectionFilter == null || sectionFilter.equalsIgnoreCase(ALL_SECTIONS);

        StringBuilder sb = new StringBuilder();
        sb.append("=== Condominium Parking Rental Report");
        sb.append(allSections ? " (All Sections) ===\n" : " (" + sectionFilter + ") ===\n");

        int totalSold = 0, totalAvailable = 0;
        double totalRevenue = 0.0;

        for (Floor floor : floors) {
            if (!allSections && !floor.getSection().equalsIgnoreCase(sectionFilter)) {
                continue;
            }

            sb.append("\nSection ").append(floor.getSection()).append("\n");
            sb.append("  Available: ").append(floor.getAvailabilityCount()).append("\n");
            sb.append("  Sold: ").append(floor.getSoldCount()).append("\n");

            for (Slot slot : floor.getSlots()) {
                if (slot.getStatus().equals(Slot.STATUS_SOLD)) {
                    sb.append("    - ").append(slot).append(" | ")
                      .append(slot.getCustomerName()).append(" | Unit ")
                      .append(slot.getUnit()).append(" | ")
                      .append(slot.getRentDuration()).append(" ")
                      .append(slot.getRentDurationUnit()).append("(s) | Php ")
                      .append(String.format("%.2f", slot.getAmountPaid())).append("\n");
                    totalRevenue += slot.getAmountPaid();
                }
            }

            totalSold += floor.getSoldCount();
            totalAvailable += floor.getAvailabilityCount();
        }

        sb.append("\n-------------------------------\n");
        sb.append("Total Available: ").append(totalAvailable).append("\n");
        sb.append("Total Sold: ").append(totalSold).append("\n");
        sb.append("Total Revenue: Php ").append(String.format("%.2f", totalRevenue)).append("\n");

        return sb.toString();
    }

    public List<ReportRow> getReportRows(String sectionFilter) {
        boolean allSections = sectionFilter == null || sectionFilter.equalsIgnoreCase(ALL_SECTIONS);
        List<ReportRow> rows = new ArrayList<>();

        for (Floor floor : floors) {
            if (!allSections && !floor.getSection().equalsIgnoreCase(sectionFilter)) {
                continue;
            }
            for (Slot slot : floor.getSlots()) {
                if (!slot.getStatus().equals(Slot.STATUS_SOLD)) continue;

                Vehicle v = slot.getVehicle();
                rows.add(new ReportRow(
                        floor.getSection(),
                        slot.getSlotNumber(),
                        slot.isPWD(),
                        slot.getCustomerName(),
                        slot.getCustomerContact(),
                        slot.getUnit(),
                        slot.getUnitId(),
                        v != null ? v.getPlateNo() : "",
                        v != null ? v.getCarType() : "",
                        v != null && v.isECar(),
                        slot.getRentDuration(),
                        slot.getRentDurationUnit(),
                        slot.getAmountPaid()
                ));
            }
        }
        return rows;
    }

    // stat summary
    public int getAvailabilityCount(String sectionFilter) {
        boolean allSections = sectionFilter == null || sectionFilter.equalsIgnoreCase(ALL_SECTIONS);
        int total = 0;
        for (Floor floor : floors) {
            if (allSections || floor.getSection().equalsIgnoreCase(sectionFilter)) {
                total += floor.getAvailabilityCount();
            }
        }
        return total;
    }

    public int getSoldCount(String sectionFilter) {
        boolean allSections = sectionFilter == null || sectionFilter.equalsIgnoreCase(ALL_SECTIONS);
        int total = 0;
        for (Floor floor : floors) {
            if (allSections || floor.getSection().equalsIgnoreCase(sectionFilter)) {
                total += floor.getSoldCount();
            }
        }
        return total;
    }

    public double getTotalRevenue(String sectionFilter) {
        double total = 0.0;
        for (ReportRow row : getReportRows(sectionFilter)) {
            total += row.amountPaid;
        }
        return total;
    }

    // deets for the rented slot
    public static class ReportRow {
        public final String section;
        public final int slotNumber;
        public final boolean pwd;
        public final String customerName;
        public final String customerContact;
        public final String unit;
        public final String unitId;
        public final String plateNo;
        public final String carType;
        public final boolean eCar;
        public final int rentDuration;
        public final String rentDurationUnit;
        public final double amountPaid;

        public ReportRow(String section, int slotNumber, boolean pwd, String customerName,
                          String customerContact, String unit, String unitId, String plateNo,
                          String carType, boolean eCar, int rentDuration, String rentDurationUnit,
                          double amountPaid) {
            this.section = section;
            this.slotNumber = slotNumber;
            this.pwd = pwd;
            this.customerName = customerName;
            this.customerContact = customerContact;
            this.unit = unit;
            this.unitId = unitId;
            this.plateNo = plateNo;
            this.carType = carType;
            this.eCar = eCar;
            this.rentDuration = rentDuration;
            this.rentDurationUnit = rentDurationUnit;
            this.amountPaid = amountPaid;
        }
    }

    // one entry in the admin's cancellation log
    public static class CancellationRow {
        public final String cancelledAt;
        public final String section;
        public final int slotNumber;
        public final String customerName;
        public final String customerContact;
        public final String unit;
        public final String unitId;
        public final String plateNo;
        public final int rentDuration;
        public final String rentDurationUnit;
        public final double amountPaid;
        public final String cancelledBy;

        public CancellationRow(String cancelledAt, String section, int slotNumber, String customerName,
                                String customerContact, String unit, String unitId, String plateNo,
                                int rentDuration, String rentDurationUnit, double amountPaid,
                                String cancelledBy) {
            this.cancelledAt = cancelledAt;
            this.section = section;
            this.slotNumber = slotNumber;
            this.customerName = customerName;
            this.customerContact = customerContact;
            this.unit = unit;
            this.unitId = unitId;
            this.plateNo = plateNo;
            this.rentDuration = rentDuration;
            this.rentDurationUnit = rentDurationUnit;
            this.amountPaid = amountPaid;
            this.cancelledBy = cancelledBy;
        }
    }

    // one pending cancel request waiting for the admin
    public static class CancelRequestRow {
        public final int requestId;
        public final String requestedAt;
        public final String section;
        public final int slotNumber;
        public final String customerName;
        public final String customerContact;
        public final String unit;
        public final String unitId;
        public final String plateNo;
        public final int rentDuration;
        public final String rentDurationUnit;
        public final double amountPaid;

        public CancelRequestRow(int requestId, String requestedAt, String section, int slotNumber,
                                 String customerName, String customerContact, String unit, String unitId,
                                 String plateNo, int rentDuration, String rentDurationUnit, double amountPaid) {
            this.requestId = requestId;
            this.requestedAt = requestedAt;
            this.section = section;
            this.slotNumber = slotNumber;
            this.customerName = customerName;
            this.customerContact = customerContact;
            this.unit = unit;
            this.unitId = unitId;
            this.plateNo = plateNo;
            this.rentDuration = rentDuration;
            this.rentDurationUnit = rentDurationUnit;
            this.amountPaid = amountPaid;
        }
    }

    // shows when the payment was successful or failed
    public static class TransactionResult {
        public final boolean success;
        public final String message;
        public final double amount;

        public TransactionResult(boolean success, String message, double amount) {
            this.success = success;
            this.message = message;
            this.amount = amount;
        }
    }
}