package lib;

import java.util.ArrayList;
import java.util.List;


public class Floor {
    public static final String UNIT_DAY = "Day";
    public static final String UNIT_WEEK = "Week";
    public static final String UNIT_MONTH = "Month";

    private static final double DAYS_PER_MONTH = 30.0;
    private static final double WEEKS_PER_MONTH = 4.0;

    private int floorId = -1; // maps to FLOOR.floorID; -1 = not persisted yet
    private String section;
    private double regularPrice;  
    private double discountPrice; 
    private List<Slot> slots;

    public Floor(String section, double regularPrice, double discountPrice) {
        this.section = section;
        this.regularPrice = regularPrice;
        this.discountPrice = discountPrice;
        this.slots = new ArrayList<>();
    }

    public int getFloorId() {
        return floorId;
    }

    public void setFloorId(int floorId) {
        this.floorId = floorId;
    }

    public String getSection() {
        return section;
    }

    public double getRegularPrice() {
        return regularPrice;
    }

    public double getDiscountPrice() {
        return discountPrice;
    }

    // adds slots to the floor
    public void addSlot(Slot slot) {
        slots.add(slot);
    }

    public List<Slot> getSlots() {
        return slots;
    }

    // you make look at the slots from this based on the slot's number
    public Slot getSlot(int slotNumber) {
        for (Slot s : slots) {
            if (s.getSlotNumber() == slotNumber) {
                return s;
            }
        }
        return null;
    }

    public int getAvailabilityCount() {
        int count = 0;
        for (Slot s : slots) {
            if (s.getStatus().equals(Slot.STATUS_AVAILABLE)) {
                count++;
            }
        }
        return count;
    }

    public int getSoldCount() {
        int count = 0;
        for (Slot s : slots) {
            if (s.getStatus().equals(Slot.STATUS_SOLD)) {
                count++;
            }
        }
        return count;
    }

    // monthly price 
    public double getPriceFor(Slot slot) {
        return slot.isPWD() ? discountPrice : regularPrice;
    }

    // rates for the rent
    public double getRateFor(Slot slot, String unit) {
        double monthly = getPriceFor(slot);
        if (UNIT_DAY.equals(unit)) {
            return monthly / DAYS_PER_MONTH;
        } else if (UNIT_WEEK.equals(unit)) {
            return monthly / WEEKS_PER_MONTH;
        }
        return monthly; 
    }

    @Override
    public String toString() {
        return "Section " + section + " - " + getAvailabilityCount() + " available / "
                + slots.size() + " total";
    }
}