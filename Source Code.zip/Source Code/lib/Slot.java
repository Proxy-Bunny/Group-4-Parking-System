package lib;

public class Slot {
    public static final String STATUS_AVAILABLE = "Available";
    public static final String STATUS_SOLD = "Sold";

    private int slotId = -1;     
    private int customerId = -1;  
    private int vehicleId = -1;  

    private int slotNumber;
    private boolean isPWD;
    private boolean isECarOnly; 
    private String status;

    // will be filled once the slot is sold/rented
    private String customerName;
    private String customerContact;
    private String unit;
    private String unitId;
    private int rentDuration;       
    private String rentDurationUnit; 
    private double amountPaid;      
    private Vehicle vehicle;

    public Slot(int slotNumber, boolean isPWD) {
        this(slotNumber, isPWD, false);
    }

    public Slot(int slotNumber, boolean isPWD, boolean isECarOnly) {
        this.slotNumber = slotNumber;
        this.isPWD = isPWD;
        this.isECarOnly = isECarOnly;
        this.status = STATUS_AVAILABLE;
    }

    // resets all detail
    public void clearSlot() {
        this.customerName = null;
        this.customerContact = null;
        this.unit = null;
        this.unitId = null;
        this.rentDuration = 0;
        this.rentDurationUnit = null;
        this.amountPaid = 0;
        this.vehicle = null;
        this.status = STATUS_AVAILABLE;
        this.customerId = -1;
        this.vehicleId = -1;
    }

    public int getSlotId() { return slotId; }
    public void setSlotId(int slotId) { this.slotId = slotId; }
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public int getVehicleId() { return vehicleId; }
    public void setVehicleId(int vehicleId) { this.vehicleId = vehicleId; }
    public boolean isECarOnly() { return isECarOnly; }
    public boolean isPWD() { return isPWD; }
    public String getStatus() { return status; }
    public double getAmountPaid() { return amountPaid; }
    public String getCustomerName() { return customerName; }
    public String getCustomerContact() { return customerContact; }
    public String getUnit() { return unit; }
    public String getUnitId() { return unitId; }
    public int getRentDuration() { return rentDuration; }
    public String getRentDurationUnit() { return rentDurationUnit; }
    public int getSlotNumber() { return slotNumber; }
    public Vehicle getVehicle() { return vehicle; }

    public void sellSlot(String customerName, String customerContact, String unit,
                          String unitId, int rentDuration, String rentDurationUnit,
                          double amountPaid, Vehicle vehicle) {
        this.customerName = customerName;
        this.customerContact = customerContact;
        this.unit = unit;
        this.unitId = unitId;
        this.rentDuration = rentDuration;
        this.rentDurationUnit = rentDurationUnit;
        this.amountPaid = amountPaid;
        this.vehicle = vehicle;
        this.status = STATUS_SOLD;
    }

    @Override
    public String toString() {
        return "Slot " + slotNumber + (isPWD ? " (PWD)" : "") + " - " + status;
    }
}