package lib;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


public class ParkingDAO {

    private static final String SELECT_FLOORS =
            "SELECT floorID, section, regularPrice, discountPrice FROM FLOOR ORDER BY floorID";

    private static final String SELECT_SLOTS_FOR_FLOOR =
            "SELECT s.slotID, s.slotNumber, s.isPWD, s.isECarOnly, s.status, "
          + "       s.unit, s.unitID, s.rentDuration, s.rentDurationUnit, s.amountPaid, "
          + "       s.customerID, s.vehicleID, c.customerName, c.customerContact, "
          + "       v.plateNo, v.carType, v.isECar "
          + "FROM SLOT s "
          + "LEFT JOIN CUSTOMER c ON s.customerID = c.customerID "
          + "LEFT JOIN VEHICLE v ON s.vehicleID = v.vehicleID "
          + "WHERE s.floorID = ? "
          + "ORDER BY s.slotNumber";

    private static final String INSERT_CUSTOMER =
            "INSERT INTO CUSTOMER (customerName, customerContact) VALUES (?, ?)";

    private static final String INSERT_VEHICLE =
            "INSERT INTO VEHICLE (plateNo, carType, isECar) VALUES (?, ?, ?)";

    private static final String UPDATE_SLOT =
            "UPDATE SLOT SET status = ?, customerID = ?, vehicleID = ?, unit = ?, unitID = ?, "
          + "                 rentDuration = ?, rentDurationUnit = ?, amountPaid = ? "
          + "WHERE slotID = ?";

    private static final String CANCEL_SLOT =
            "UPDATE SLOT SET status = ?, customerID = NULL, vehicleID = NULL, unit = NULL, "
          + "                 unitID = NULL, rentDuration = 0, rentDurationUnit = NULL, amountPaid = 0 "
          + "WHERE slotID = ?";

    // Created automatically the first time it's needed, so no manual SQL setup is required
    private static final String CREATE_LOG_TABLE =
            "CREATE TABLE IF NOT EXISTS CANCELLATION_LOG ("
          + "  logID INT AUTO_INCREMENT PRIMARY KEY,"
          + "  cancelledAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
          + "  section VARCHAR(50), slotNumber INT,"
          + "  customerName VARCHAR(100), customerContact VARCHAR(20),"
          + "  unit VARCHAR(50), unitID VARCHAR(50), plateNo VARCHAR(20),"
          + "  rentDuration INT, rentDurationUnit VARCHAR(10), amountPaid DOUBLE,"
          + "  cancelledBy VARCHAR(20))";

    private static final String INSERT_LOG =
            "INSERT INTO CANCELLATION_LOG (section, slotNumber, customerName, customerContact, unit, unitID, "
          + "                              plateNo, rentDuration, rentDurationUnit, amountPaid, cancelledBy) "
          + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_LOG =
            "SELECT cancelledAt, section, slotNumber, customerName, customerContact, unit, unitID, plateNo, "
          + "       rentDuration, rentDurationUnit, amountPaid, cancelledBy "
          + "FROM CANCELLATION_LOG ORDER BY cancelledAt DESC, logID DESC";

    private static final String CREATE_REQUEST_TABLE =
            "CREATE TABLE IF NOT EXISTS CANCEL_REQUEST ("
          + "  requestID INT AUTO_INCREMENT PRIMARY KEY,"
          + "  requestedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
          + "  slotID INT NOT NULL,"
          + "  section VARCHAR(50), slotNumber INT,"
          + "  customerName VARCHAR(100), customerContact VARCHAR(20),"
          + "  unit VARCHAR(50), unitID VARCHAR(50), plateNo VARCHAR(20),"
          + "  rentDuration INT, rentDurationUnit VARCHAR(10), amountPaid DOUBLE,"
          + "  status VARCHAR(10) NOT NULL DEFAULT 'Pending',"
          + "  resolvedAt TIMESTAMP NULL DEFAULT NULL,"
          + "  resolvedBy VARCHAR(40))";

    private static final String INSERT_REQUEST =
            "INSERT INTO CANCEL_REQUEST (slotID, section, slotNumber, customerName, customerContact, unit, "
          + "                            unitID, plateNo, rentDuration, rentDurationUnit, amountPaid) "
          + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String COUNT_PENDING =
            "SELECT COUNT(*) FROM CANCEL_REQUEST WHERE slotID = ? AND status = 'Pending'";

    private static final String SELECT_PENDING =
            "SELECT requestID, requestedAt, section, slotNumber, customerName, customerContact, unit, unitID, "
          + "       plateNo, rentDuration, rentDurationUnit, amountPaid "
          + "FROM CANCEL_REQUEST WHERE status = 'Pending' ORDER BY requestedAt, requestID";

    private static final String DECLINE_REQUEST =
            "UPDATE CANCEL_REQUEST SET status = 'Declined', resolvedAt = CURRENT_TIMESTAMP, resolvedBy = ? "
          + "WHERE requestID = ? AND status = 'Pending'";

    // when a rental is cancelled, any waiting request for that slot is finished too
    private static final String RESOLVE_REQUESTS =
            "UPDATE CANCEL_REQUEST SET status = 'Approved', resolvedAt = CURRENT_TIMESTAMP, resolvedBy = ? "
          + "WHERE slotID = ? AND status = 'Pending'";

    // Loads every floor and its slots 
    public ParkingSystem loadFloors() throws SQLException {
        ParkingSystem system = new ParkingSystem();

        try (Connection conn = Database.getConnection();
             PreparedStatement floorStmt = conn.prepareStatement(SELECT_FLOORS);
             ResultSet floorRs = floorStmt.executeQuery()) {

            while (floorRs.next()) {
                int floorId = floorRs.getInt("floorID");

                Floor floor = new Floor(
                        floorRs.getString("section"),
                        floorRs.getDouble("regularPrice"),
                        floorRs.getDouble("discountPrice")
                );
                floor.setFloorId(floorId);

                loadSlotsForFloor(conn, floor);
                system.addFloor(floor);
            }
        }

        return system;
    }

    private void loadSlotsForFloor(Connection conn, Floor floor) throws SQLException {
        try (PreparedStatement slotStmt = conn.prepareStatement(SELECT_SLOTS_FOR_FLOOR)) {
            slotStmt.setInt(1, floor.getFloorId());

            try (ResultSet rs = slotStmt.executeQuery()) {
                while (rs.next()) {
                    Slot slot = new Slot(
                            rs.getInt("slotNumber"),
                            rs.getBoolean("isPWD"),
                            rs.getBoolean("isECarOnly")
                    );
                    slot.setSlotId(rs.getInt("slotID"));

                    if (Slot.STATUS_SOLD.equals(rs.getString("status"))) {
                        Vehicle vehicle = null;
                        String plateNo = rs.getString("plateNo");
                        if (plateNo != null) {
                            vehicle = new Vehicle(plateNo, rs.getString("carType"), rs.getBoolean("isECar"));
                            vehicle.setVehicleId(rs.getInt("vehicleID"));
                        }

                        slot.sellSlot(
                                rs.getString("customerName"),
                                rs.getString("customerContact"),
                                rs.getString("unit"),
                                rs.getString("unitID"),
                                rs.getInt("rentDuration"),
                                rs.getString("rentDurationUnit"),
                                rs.getDouble("amountPaid"),
                                vehicle
                        );
                        slot.setCustomerId(rs.getInt("customerID"));
                        slot.setVehicleId(rs.getInt("vehicleID"));
                    }

                    floor.addSlot(slot);
                }
            }
        }
    }

    // complete rental deet
    public void saveTransaction(Slot slot, String customerName, String customerContact,
                                 String unit, String unitId, int rentDuration, String rentDurationUnit,
                                 double amountPaid, Vehicle vehicle) throws SQLException {
        if (slot.getSlotId() <= 0) {
            return;
        }

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                int customerId = insertCustomer(conn, customerName, customerContact);
                int vehicleId = insertVehicle(conn, vehicle);
                updateSlot(conn, slot.getSlotId(), customerId, vehicleId, unit, unitId,
                        rentDuration, rentDurationUnit, amountPaid);

                conn.commit();
                slot.setCustomerId(customerId);
                slot.setVehicleId(vehicleId);
                if (vehicle != null) {
                    vehicle.setVehicleId(vehicleId);
                }
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // cancel
    public void cancelTransaction(Slot slot, String section, String cancelledBy) throws SQLException {
        if (slot.getSlotId() <= 0) {
            return;
        }

        Vehicle vehicle = slot.getVehicle();

        try (Connection conn = Database.getConnection()) {
            ensureTables(conn);

            conn.setAutoCommit(false);
            try {
                try (PreparedStatement log = conn.prepareStatement(INSERT_LOG)) {
                    log.setString(1, section);
                    log.setInt(2, slot.getSlotNumber());
                    log.setString(3, slot.getCustomerName());
                    log.setString(4, slot.getCustomerContact());
                    log.setString(5, slot.getUnit());
                    log.setString(6, slot.getUnitId());
                    log.setString(7, vehicle != null ? vehicle.getPlateNo() : null);
                    log.setInt(8, slot.getRentDuration());
                    log.setString(9, slot.getRentDurationUnit());
                    log.setDouble(10, slot.getAmountPaid());
                    log.setString(11, cancelledBy);
                    log.executeUpdate();
                }

                try (PreparedStatement stmt = conn.prepareStatement(CANCEL_SLOT)) {
                    stmt.setString(1, Slot.STATUS_AVAILABLE);
                    stmt.setInt(2, slot.getSlotId());
                    stmt.executeUpdate();
                }

                try (PreparedStatement stmt = conn.prepareStatement(RESOLVE_REQUESTS)) {
                    stmt.setString(1, cancelledBy);
                    stmt.setInt(2, slot.getSlotId());
                    stmt.executeUpdate();
                }

                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // Newest cancellations first
    public List<ParkingSystem.CancellationRow> loadCancellations() throws SQLException {
        List<ParkingSystem.CancellationRow> rows = new ArrayList<>();
        SimpleDateFormat fmt = new SimpleDateFormat("MMM dd, yyyy hh:mm a");

        try (Connection conn = Database.getConnection()) {
            ensureTables(conn);

            try (PreparedStatement stmt = conn.prepareStatement(SELECT_LOG);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Timestamp ts = rs.getTimestamp("cancelledAt");
                    rows.add(new ParkingSystem.CancellationRow(
                            ts != null ? fmt.format(ts) : "",
                            rs.getString("section"),
                            rs.getInt("slotNumber"),
                            rs.getString("customerName"),
                            rs.getString("customerContact"),
                            rs.getString("unit"),
                            rs.getString("unitID"),
                            rs.getString("plateNo"),
                            rs.getInt("rentDuration"),
                            rs.getString("rentDurationUnit"),
                            rs.getDouble("amountPaid"),
                            rs.getString("cancelledBy")
                    ));
                }
            }
        }
        return rows;
    }

    private void ensureTables(Connection conn) throws SQLException {
        try (Statement st = conn.createStatement()) {
            st.execute(CREATE_LOG_TABLE);
            st.execute(CREATE_REQUEST_TABLE);
        }
    }

    public boolean hasPendingRequest(Slot slot) throws SQLException {
        if (slot.getSlotId() <= 0) {
            return false;
        }
        try (Connection conn = Database.getConnection()) {
            ensureTables(conn);
            try (PreparedStatement stmt = conn.prepareStatement(COUNT_PENDING)) {
                stmt.setInt(1, slot.getSlotId());
                try (ResultSet rs = stmt.executeQuery()) {
                    return rs.next() && rs.getInt(1) > 0;
                }
            }
        }
    }

    // cancel request from customers wont cancel right away, it still needs the admin's approval
    public void saveCancelRequest(Slot slot, String section) throws SQLException {
        if (slot.getSlotId() <= 0) {
            return;
        }
        Vehicle vehicle = slot.getVehicle();

        try (Connection conn = Database.getConnection()) {
            ensureTables(conn);
            try (PreparedStatement stmt = conn.prepareStatement(INSERT_REQUEST)) {
                stmt.setInt(1, slot.getSlotId());
                stmt.setString(2, section);
                stmt.setInt(3, slot.getSlotNumber());
                stmt.setString(4, slot.getCustomerName());
                stmt.setString(5, slot.getCustomerContact());
                stmt.setString(6, slot.getUnit());
                stmt.setString(7, slot.getUnitId());
                stmt.setString(8, vehicle != null ? vehicle.getPlateNo() : null);
                stmt.setInt(9, slot.getRentDuration());
                stmt.setString(10, slot.getRentDurationUnit());
                stmt.setDouble(11, slot.getAmountPaid());
                stmt.executeUpdate();
            }
        }
    }

    // Oldest request first
    public List<ParkingSystem.CancelRequestRow> loadPendingRequests() throws SQLException {
        List<ParkingSystem.CancelRequestRow> rows = new ArrayList<>();
        SimpleDateFormat fmt = new SimpleDateFormat("MMM dd, yyyy hh:mm a");

        try (Connection conn = Database.getConnection()) {
            ensureTables(conn);
            try (PreparedStatement stmt = conn.prepareStatement(SELECT_PENDING);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Timestamp ts = rs.getTimestamp("requestedAt");
                    rows.add(new ParkingSystem.CancelRequestRow(
                            rs.getInt("requestID"),
                            ts != null ? fmt.format(ts) : "",
                            rs.getString("section"),
                            rs.getInt("slotNumber"),
                            rs.getString("customerName"),
                            rs.getString("customerContact"),
                            rs.getString("unit"),
                            rs.getString("unitID"),
                            rs.getString("plateNo"),
                            rs.getInt("rentDuration"),
                            rs.getString("rentDurationUnit"),
                            rs.getDouble("amountPaid")
                    ));
                }
            }
        }
        return rows;
    }

    public boolean declineRequest(int requestId, String declinedBy) throws SQLException {
        try (Connection conn = Database.getConnection()) {
            ensureTables(conn);
            try (PreparedStatement stmt = conn.prepareStatement(DECLINE_REQUEST)) {
                stmt.setString(1, declinedBy);
                stmt.setInt(2, requestId);
                return stmt.executeUpdate() > 0;
            }
        }
    }

    private int insertCustomer(Connection conn, String name, String contact) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(INSERT_CUSTOMER, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, name);
            stmt.setString(2, contact);
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private int insertVehicle(Connection conn, Vehicle vehicle) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(INSERT_VEHICLE, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, vehicle.getPlateNo());
            stmt.setString(2, vehicle.getCarType());
            stmt.setBoolean(3, vehicle.isECar());
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private void updateSlot(Connection conn, int slotId, int customerId, int vehicleId,
                             String unit, String unitId, int rentDuration, String rentDurationUnit,
                             double amountPaid) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(UPDATE_SLOT)) {
            stmt.setString(1, Slot.STATUS_SOLD);
            stmt.setInt(2, customerId);
            stmt.setInt(3, vehicleId);
            stmt.setString(4, unit);
            stmt.setString(5, unitId);
            stmt.setInt(6, rentDuration);
            stmt.setString(7, rentDurationUnit);
            stmt.setDouble(8, amountPaid);
            stmt.setInt(9, slotId);
            stmt.executeUpdate();
        }
    }
}