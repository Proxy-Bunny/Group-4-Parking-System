package app;

import javax.swing.*;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.util.Enumeration;

public class Theme {

    public static final Color BG          = new Color(0x0F1419);
    public static final Color SURFACE     = new Color(0x1A212B); 
    public static final Color SURFACE_ALT = new Color(0x222B37); 
    public static final Color BORDER      = new Color(0x2E3945);
    public static final Color TEXT        = new Color(0xE6EAF0);
    public static final Color MUTED       = new Color(0x8B96A5);
    public static final Color ACCENT      = new Color(0x1FB5A3); 
    public static final Color ACCENT_DARK = new Color(0x137A6E);

    private static ColorUIResource c(Color color) {
        return new ColorUIResource(color);
    }

    public static void apply() {
        try {
           
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) { }

        // Font
        Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            if (UIManager.get(key) instanceof FontUIResource) {
                UIManager.put(key, new FontUIResource("Segoe UI", Font.PLAIN, 13));
            }
        }

        // General
        UIManager.put("Panel.background", c(BG));
        UIManager.put("Label.foreground", c(TEXT));
        UIManager.put("Separator.foreground", c(BORDER));
        UIManager.put("Separator.background", c(BORDER));
        UIManager.put("ToolTip.background", c(SURFACE_ALT));
        UIManager.put("ToolTip.foreground", c(TEXT));
        UIManager.put("ToolTip.border", BorderFactory.createLineBorder(BORDER));

        // Dialogs 
        UIManager.put("OptionPane.background", c(SURFACE));
        UIManager.put("OptionPane.messageForeground", c(TEXT));

        UIManager.put("Button.gradient", null);
        UIManager.put("Button.background", ACCENT);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.select", c(ACCENT_DARK));
        UIManager.put("Button.focus", c(ACCENT_DARK));
        UIManager.put("Button.border", new BorderUIResource(BorderFactory.createEmptyBorder(9, 20, 9, 20)));

        // Text inputs
        for (String field : new String[] { "TextField", "PasswordField" }) {
            UIManager.put(field + ".background", c(SURFACE_ALT));
            UIManager.put(field + ".foreground", c(TEXT));
            UIManager.put(field + ".caretForeground", c(TEXT));
            UIManager.put(field + ".selectionBackground", c(ACCENT));
            UIManager.put(field + ".selectionForeground", c(Color.WHITE));
            UIManager.put(field + ".border", BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER),
                    BorderFactory.createEmptyBorder(5, 8, 5, 8)));
        }

        // Flat combo boxes and scroll bars 
        UIManager.put("ComboBoxUI", "javax.swing.plaf.basic.BasicComboBoxUI");
        UIManager.put("ScrollBarUI", "javax.swing.plaf.basic.BasicScrollBarUI");
        UIManager.put("ComboBox.border", BorderFactory.createLineBorder(BORDER));
        UIManager.put("ScrollBar.width", 12);

        // Combo boxes 
        UIManager.put("ComboBox.background", c(SURFACE_ALT));
        UIManager.put("ComboBox.foreground", c(TEXT));
        UIManager.put("ComboBox.selectionBackground", c(ACCENT));
        UIManager.put("ComboBox.selectionForeground", c(Color.WHITE));
        UIManager.put("ComboBox.buttonBackground", c(SURFACE_ALT));
        UIManager.put("ComboBox.buttonShadow", c(BORDER));
        UIManager.put("ComboBox.buttonDarkShadow", c(MUTED));
        UIManager.put("ComboBox.buttonHighlight", c(BORDER));
        UIManager.put("List.background", c(SURFACE_ALT));
        UIManager.put("List.foreground", c(TEXT));
        UIManager.put("List.selectionBackground", c(ACCENT));
        UIManager.put("List.selectionForeground", c(Color.WHITE));

        // Check boxes
        UIManager.put("CheckBox.background", c(BG));
        UIManager.put("CheckBox.foreground", c(TEXT));

        // Scroll panes / scroll bars
        UIManager.put("ScrollPane.background", c(BG));
        UIManager.put("Viewport.background", c(BG));
        UIManager.put("ScrollPane.border", BorderFactory.createLineBorder(BORDER));
        UIManager.put("ScrollBar.background", c(BG));
        UIManager.put("ScrollBar.track", c(BG));
        UIManager.put("ScrollBar.thumb", c(SURFACE_ALT));
        UIManager.put("ScrollBar.thumbShadow", c(BORDER));
        UIManager.put("ScrollBar.thumbHighlight", c(BORDER));
        UIManager.put("ScrollBar.thumbDarkShadow", c(BORDER));

        // Tabs
        UIManager.put("TabbedPane.background", c(SURFACE));
        UIManager.put("TabbedPane.foreground", c(MUTED));
        UIManager.put("TabbedPane.selectedForeground", c(TEXT));
        UIManager.put("TabbedPane.selected", c(SURFACE));
        UIManager.put("TabbedPane.contentAreaColor", c(BG));
        UIManager.put("TabbedPane.tabAreaBackground", c(BG));
        UIManager.put("TabbedPane.light", c(BG));
        UIManager.put("TabbedPane.highlight", c(ACCENT));
        UIManager.put("TabbedPane.shadow", c(BORDER));
        UIManager.put("TabbedPane.darkShadow", c(BORDER));
        UIManager.put("TabbedPane.focus", c(ACCENT));
        UIManager.put("TabbedPane.selectHighlight", c(ACCENT));
        UIManager.put("TabbedPane.borderHightlightColor", c(BORDER));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(1, 0, 0, 0));

        // Tables
        UIManager.put("Table.background", c(SURFACE));
        UIManager.put("Table.foreground", c(TEXT));
        UIManager.put("Table.gridColor", c(BORDER));
        UIManager.put("Table.selectionBackground", c(ACCENT_DARK));
        UIManager.put("Table.selectionForeground", c(Color.WHITE));
        UIManager.put("TableHeader.background", c(SURFACE_ALT));
        UIManager.put("TableHeader.foreground", c(TEXT));
        UIManager.put("TableHeader.cellBorder", BorderFactory.createMatteBorder(0, 0, 1, 1, BORDER));
    }

    // Flat tabs
    public static void styleTabs(JTabbedPane tabs) {
        tabs.setUI(new FlatTabbedPaneUI());
    }

    public static class FlatTabbedPaneUI extends javax.swing.plaf.basic.BasicTabbedPaneUI {
        @Override
        protected void installDefaults() {
            super.installDefaults();
            tabInsets = new Insets(9, 22, 9, 22);
            selectedTabPadInsets = new Insets(0, 0, 0, 0);
            tabAreaInsets = new Insets(0, 0, 0, 0);
            contentBorderInsets = new Insets(0, 0, 0, 0);
        }

        @Override
        protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex,
                                          int x, int y, int w, int h, boolean isSelected) {
            g.setColor(isSelected ? BG : SURFACE);
            g.fillRect(x, y, w, h);
            if (isSelected) {
                g.setColor(ACCENT);
                g.fillRect(x, y + h - 3, w, 3);
            }
        }

        @Override
        protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex,
                                      int x, int y, int w, int h, boolean isSelected) { }

        @Override
        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) { }

        @Override
        protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects,
                                           int tabIndex, Rectangle iconRect, Rectangle textRect,
                                           boolean isSelected) { }
    }

    // Teal filled button for the main action
    public static void primary(JButton b) {
        b.setBackground(ACCENT);
        b.setForeground(Color.WHITE);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(9, 20, 9, 20));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    // Dark outlined button for the secondary actions~
    public static void secondary(JButton b) {
        b.setBackground(SURFACE_ALT);
        b.setForeground(TEXT);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(7, 16, 7, 16)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
}