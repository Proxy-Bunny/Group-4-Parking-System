package app;

import lib.Floor;
import lib.ParkingSystem;
import lib.Slot;
import lib.Vehicle;
import lib.ParkingDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Frontend extends JFrame {
    private ParkingSystem system;
    private final ParkingSystem.Role role;

    // color coding per parking!
    private static final Color COLOR_PWD = new Color(0x42, 0x85, 0xF4);
    private static final Color COLOR_ECAR = new Color(0x9C, 0x27, 0xB0);
    private static final Color COLOR_REGULAR = Color.RED;
    private static final Color COLOR_SOLD = Color.GREEN;

    private static final int CONTACT_MAX_LEN = 11;
    private static final int PLATE_MAX_LEN = 7;

    // Card Layout Components
    private JPanel bookingCards;
    private CardLayout cardLayout;
    private static final String VIEW_SLOTS = "Slots";
    private static final String VIEW_FORM = "Form";

    // Booking components
    private JPanel rightInfoPanel;             
    private JComboBox<String> sectionCombo;
    private JComboBox<String> slotFilterCombo; 
    private JPanel slotGridPanel;              
    private JButton selectedSlotButton;
    private int selectedSlotNumber = -1;
    
    private JLabel availabilityLabel;
    private JLabel priceLabel;
    private JCheckBox pwdCheckBox;
    private JCheckBox eCarOnlyCheckBox; 
    private JTextField nameField, contactField, unitField, unitIdField;
    private JTextField durationCountField;
    private JComboBox<String> durationUnitCombo;
    private JTextField plateField;
    private JComboBox<String> carTypeCombo;

    // Report components
    private JComboBox<String> reportSectionCombo;
    private JTable reportTable;
    private DefaultTableModel reportTableModel;
    private JLabel reportSummaryLabel;
    private List<ParkingSystem.ReportRow> currentReportRows = new ArrayList<>();

    // Cancellation log components (admin only)
    private JPanel cancelPanel;
    private DefaultTableModel cancelTableModel;
    private JLabel cancelSummaryLabel;

    // Cancel request components (admin only)
    private static final String REQUESTS_TAB_TITLE = "Cancel Requests";
    private JTabbedPane mainTabs;
    private JPanel requestPanel;
    private DefaultTableModel requestTableModel;
    private JTable requestTable;
    private JLabel requestSummaryLabel;
    private List<ParkingSystem.CancelRequestRow> currentRequests = new ArrayList<>();

    public Frontend(ParkingSystem system, ParkingSystem.Role role) {
        super("Condominium Parking Rental System");
        this.system = system;
        this.role = role;

        JTabbedPane tabs = new JTabbedPane();
        mainTabs = tabs;
        Theme.styleTabs(tabs);
        tabs.addTab("Book a Slot", makeBookingTab());

        // Reports (and invoices) are for admins only
        if (role == ParkingSystem.Role.ADMIN) {
            tabs.addTab("Reports", makeReportTab());
            requestPanel = makeRequestTab();
            tabs.addTab(REQUESTS_TAB_TITLE, requestPanel);
            cancelPanel = makeCancellationTab();
            tabs.addTab("Cancellations", cancelPanel);
            // refresh these tabs every time the admin opens them
            tabs.addChangeListener(e -> {
                if (tabs.getSelectedComponent() == cancelPanel) {
                    loadCancellations();
                } else if (tabs.getSelectedComponent() == requestPanel) {
                    loadCancelRequests(true);
                }
            });
            loadCancelRequests(false); // so the tab title shows how many are waiting right away
        }

        JPanel root = new JPanel(new BorderLayout());
        root.add(makeHeader(), BorderLayout.NORTH);
        root.add(tabs, BorderLayout.CENTER);

        setContentPane(root);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1040, 720);
        setLocationRelativeTo(null);
    }

    private JPanel makeBookingTab() {
        cardLayout = new CardLayout();
        bookingCards = new JPanel(cardLayout);
        bookingCards.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        //  slots
        JPanel slotSelectionPanel = new JPanel(new BorderLayout(8, 8));

        JPanel controlPanel = new JPanel(new GridLayout(3, 2, 4, 4));
        controlPanel.add(new JLabel("Section:"));
        sectionCombo = new JComboBox<>();
        for (Floor f : system.getFloors()) {
            sectionCombo.addItem(f.getSection());
        }
        sectionCombo.addActionListener(e -> rebuildSlotGrid());
        controlPanel.add(sectionCombo);

        controlPanel.add(new JLabel("Filter:"));
        slotFilterCombo = new JComboBox<>(new String[] { "All", "PWD Only", "E-Car Only", "Regular Only" });
        slotFilterCombo.addActionListener(e -> rebuildSlotGrid());
        controlPanel.add(slotFilterCombo);

        slotSelectionPanel.add(controlPanel, BorderLayout.NORTH);

        //slot boxes
        slotGridPanel = new JPanel(new GridLayout(0, 5, 6, 18)); 
        slotSelectionPanel.add(slotGridPanel, BorderLayout.CENTER);

        JLabel legendLabel = new JLabel("<html><span style='color:#4285F4;'>&#9632;</span> PWD &nbsp;"
                + "<span style='color:#9C27B0;'>&#9632;</span> E-Car &nbsp;"
                + "<span style='color:red;'>&#9632;</span> Empty &nbsp;"
                + "<span style='color:green;'>&#9632;</span> Taken</html>");
        slotSelectionPanel.add(legendLabel, BorderLayout.SOUTH);

        // booking form
        JPanel formContainer = new JPanel(new BorderLayout(8, 8));
        
        // Back Button
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("\u2190 Back to Slots");
        backButton.addActionListener(e -> {
            if (selectedSlotButton != null) {
                selectedSlotButton.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                selectedSlotButton = null;
            }
            selectedSlotNumber = -1;
            cardLayout.show(bookingCards, VIEW_SLOTS);
        });
        Theme.secondary(backButton);
        topBar.add(backButton);
        formContainer.add(topBar, BorderLayout.NORTH);
        
        //--------------------------------------------------------------------------
        rightInfoPanel = new JPanel(new GridBagLayout());
        rightInfoPanel.setBackground(Theme.SURFACE);
        rightInfoPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(20, 24, 20, 24)));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        int row = 0;

        gbc.gridx = 0; gbc.gridy = row; rightInfoPanel.add(new JLabel("Selected Slot:"), gbc);
        availabilityLabel = new JLabel("-");
        gbc.gridx = 1; gbc.gridy = row++; rightInfoPanel.add(availabilityLabel, gbc);

        gbc.gridx = 0; gbc.gridy = row; rightInfoPanel.add(new JLabel("PWD Slot:"), gbc);
        pwdCheckBox = new JCheckBox();
        pwdCheckBox.setOpaque(false);
        pwdCheckBox.setEnabled(false);
        gbc.gridx = 1; gbc.gridy = row++; rightInfoPanel.add(pwdCheckBox, gbc);

        gbc.gridx = 0; gbc.gridy = row; rightInfoPanel.add(new JLabel("E-Car Only:"), gbc);
        eCarOnlyCheckBox = new JCheckBox();
        eCarOnlyCheckBox.setOpaque(false);
        eCarOnlyCheckBox.setEnabled(false);
        gbc.gridx = 1; gbc.gridy = row++; rightInfoPanel.add(eCarOnlyCheckBox, gbc);

        gbc.gridx = 0; gbc.gridy = row; rightInfoPanel.add(new JLabel("Rate:"), gbc);
        priceLabel = new JLabel("-");
        gbc.gridx = 1; gbc.gridy = row++; rightInfoPanel.add(priceLabel, gbc);

        rightInfoPanel.add(new JSeparator(), gbcSpan(gbc, row++));

        nameField = addFormField(rightInfoPanel, gbc, row++, "Customer Name:");
        contactField = addFormField(rightInfoPanel, gbc, row++, "Customer Contact:");
        ((AbstractDocument) contactField.getDocument()).setDocumentFilter(new LengthFilter(CONTACT_MAX_LEN, true));
        unitField = addFormField(rightInfoPanel, gbc, row++, "Unit:");
        unitIdField = addFormField(rightInfoPanel, gbc, row++, "Unit ID:");

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        rightInfoPanel.add(new JLabel("Rent For:"), gbc);
        JPanel durationPanel = new JPanel(new GridLayout(1, 2, 4, 0));
        durationPanel.setOpaque(false);
        durationCountField = new JTextField();
        durationUnitCombo = new JComboBox<>(new String[] { Floor.UNIT_DAY, Floor.UNIT_WEEK, Floor.UNIT_MONTH });
        durationUnitCombo.setSelectedItem(Floor.UNIT_MONTH);
        durationUnitCombo.addActionListener(e -> updatePriceDisplay(getSelectedSlot())); 
        durationPanel.add(durationCountField);
        durationPanel.add(durationUnitCombo);
        gbc.gridx = 1; gbc.gridy = row++;
        rightInfoPanel.add(durationPanel, gbc);

        rightInfoPanel.add(new JSeparator(), gbcSpan(gbc, row++));

        plateField = addFormField(rightInfoPanel, gbc, row++, "Plate No.:");
        ((AbstractDocument) plateField.getDocument()).setDocumentFilter(new LengthFilter(PLATE_MAX_LEN, false));

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        rightInfoPanel.add(new JLabel("Car Type:"), gbc);
        carTypeCombo = new JComboBox<>(new String[] { "Class 1", "Class 2", "Class 3" });
        gbc.gridx = 1; gbc.gridy = row++;
        rightInfoPanel.add(carTypeCombo, gbc);

        JButton rentButton = new JButton("Rent Slot");
        Theme.primary(rentButton);
        rentButton.addActionListener(this::doTransaction);
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        rightInfoPanel.add(rentButton, gbc);
        
        JPanel formWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER));
        formWrapper.add(rightInfoPanel);
        formContainer.add(new JScrollPane(formWrapper), BorderLayout.CENTER);

        bookingCards.add(slotSelectionPanel, VIEW_SLOTS);
        bookingCards.add(formContainer, VIEW_FORM);

        rebuildSlotGrid();
        return bookingCards;
    }

    private GridBagConstraints gbcSpan(GridBagConstraints base, int row) {
        GridBagConstraints gbc = (GridBagConstraints) base.clone();
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        return gbc;
    }

    private JTextField addFormField(JPanel panel, GridBagConstraints gbc, int row, String label) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        panel.add(new JLabel(label), gbc);
        JTextField field = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = row;
        panel.add(field, gbc);
        return field;
    }

    private void rebuildSlotGrid() {
        slotGridPanel.removeAll();
        selectedSlotButton = null;
        selectedSlotNumber = -1;

        Floor floor = system.getFloorBySection(getSelectedSection());
        String filter = (String) slotFilterCombo.getSelectedItem();

        if (floor != null) {
            for (Slot s : floor.getSlots()) {
                if (!passesFilter(s, filter)) continue;
                JButton btn = new JButton();
                styleSlotButton(btn, s);
                btn.addActionListener(e -> {
                    if (s.getStatus().equals(Slot.STATUS_SOLD)) {
                        cancelRental(s);
                    } else {
                        selectSlot(s.getSlotNumber(), btn);
                    }
                });
                slotGridPanel.add(btn);
            }
        }

        slotGridPanel.revalidate();
        slotGridPanel.repaint();
        if (cardLayout != null) {
            cardLayout.show(bookingCards, VIEW_SLOTS);
        }
    }

    private boolean passesFilter(Slot slot, String filter) {
        if ("PWD Only".equals(filter)) return slot.isPWD();
        if ("E-Car Only".equals(filter)) return slot.isECarOnly();
        if ("Regular Only".equals(filter)) return !slot.isPWD() && !slot.isECarOnly();
        return true; 
    }

    private void styleSlotButton(JButton btn, Slot slot) {
        boolean sold = slot.getStatus().equals(Slot.STATUS_SOLD);
        Color base = slot.isPWD() ? COLOR_PWD : (slot.isECarOnly() ? COLOR_ECAR : COLOR_REGULAR);

        btn.setOpaque(true);
        btn.setBorderPainted(true);
        btn.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        btn.setBackground(sold ? COLOR_SOLD : base);
        btn.setForeground(Color.BLACK);
        btn.setEnabled(true); // taken slots stay clickable so a rental can be cancelled
        btn.setPreferredSize(new Dimension(80, 80)); 

        String labelText = slot.isPWD() ? "PWD" : (slot.isECarOnly() ? "E-Car" : "Empty");
        if (sold) labelText = "Taken";
        
        btn.setText("<html><center><font color='black'>Slot " + slot.getSlotNumber()
                + "<br><b>" + labelText + "</b></font></center></html>");
        btn.setToolTipText("Slot " + slot.getSlotNumber() + " - " + labelText
                + (sold ? " (click to cancel rental)" : ""));

        // little car icon on taken slots
        if (sold) {
            btn.setIcon(new CarIcon());
            btn.setHorizontalTextPosition(SwingConstants.CENTER);
            btn.setVerticalTextPosition(SwingConstants.BOTTOM);
            btn.setIconTextGap(2);
        } else {
            btn.setIcon(null);
        }
    }

    private void selectSlot(int slotNumber, JButton btn) {
        if (selectedSlotButton != null) {
            selectedSlotButton.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        }
        selectedSlotNumber = slotNumber;
        selectedSlotButton = btn;
        btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
        
        // Populate form data
        Slot slot = getSelectedSlot();
        if (slot != null) {
            availabilityLabel.setText("Slot " + slot.getSlotNumber() + " (" + (slotAvailability(slot) ? "Available" : "Not Available") + ")");
            pwdCheckBox.setSelected(slot.isPWD());
            eCarOnlyCheckBox.setSelected(slot.isECarOnly());
            updatePriceDisplay(slot);
            
            // Switch to form view
            cardLayout.show(bookingCards, VIEW_FORM);
        }
    }

    private boolean slotAvailability(Slot slot) {
        return slot.getStatus().equals(Slot.STATUS_AVAILABLE);
    }

    private void updatePriceDisplay(Slot slot) {
        if (slot == null) return;
        String unit = (String) durationUnitCombo.getSelectedItem();
        double rate = system.getRate(getSelectedSection(), slot.isPWD(), unit);

        if (slot.isPWD()) {
            double regularRate = system.getRate(getSelectedSection(), false, unit);
            priceLabel.setText("Php " + String.format("%.2f", rate) + " / " + unit.toLowerCase()
                    + "  (PWD Discount applied — Regular: Php " + String.format("%.2f", regularRate) + ")");
        } else {
            priceLabel.setText("Php " + String.format("%.2f", rate) + " / " + unit.toLowerCase());
        }
    }

    private String getSelectedSection() {
        return (String) sectionCombo.getSelectedItem();
    }

    private Slot getSelectedSlot() {
        Floor floor = system.getFloorBySection(getSelectedSection());
        if (floor == null || selectedSlotNumber == -1) return null;
        return floor.getSlot(selectedSlotNumber);
    }

    private void doTransaction(ActionEvent e) {
        Slot slot = getSelectedSlot();
        if (slot == null) {
            showErrorPopup("No slot selected.");
            return;
        }

        int duration;
        try {
            duration = Integer.parseInt(durationCountField.getText().trim());
        } catch (NumberFormatException ex) {
            showErrorPopup("Rent duration must be a number.");
            return;
        }

        String durationUnit = (String) durationUnitCombo.getSelectedItem();
        

        Vehicle vehicle = new Vehicle(plateField.getText().trim(),
                (String) carTypeCombo.getSelectedItem(), slot.isECarOnly());

        ParkingSystem.TransactionResult result = system.doTransaction(
                getSelectedSection(),
                slot.getSlotNumber(),
                nameField.getText().trim(),
                contactField.getText().trim(),
                unitField.getText().trim(),
                unitIdField.getText().trim(),
                duration,
                durationUnit,
                vehicle
        );

        if (result.success) {
            JOptionPane.showMessageDialog(this,
                    result.message + "\nTotal: Php " + String.format("%.2f", result.amount),
                    "Transaction Successful", JOptionPane.INFORMATION_MESSAGE);
            clearBookingForm();
            rebuildSlotGrid(); 
        } else {
            showErrorPopup(result.message);
        }
    }

    // Admins cancel a rental right away. Customers can only send a cancel request (after confirming
    // the contact number and Unit ID they used when renting); an admin then approves or declines it
    // in the "Cancel Requests" tab.
    private void cancelRental(Slot slot) {
        String header = "Slot " + slot.getSlotNumber() + " is currently rented.";

        if (role == ParkingSystem.Role.ADMIN) {
            String[] options = { "Cancel Rental", "Keep Rental" };
            int choice = JOptionPane.showOptionDialog(this,
                    header + "\nCancel this rental and free up the slot?",
                    "Cancel Rental", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                    null, options, options[1]);
            if (choice != 0) return;

            ParkingSystem.TransactionResult result =
                    system.cancelRental(getSelectedSection(), slot.getSlotNumber(), "ADMIN");
            if (result.success) {
                JOptionPane.showMessageDialog(this, result.message,
                        "Rental Cancelled", JOptionPane.INFORMATION_MESSAGE);
                rebuildSlotGrid();
                loadCancelRequests(false); // a waiting request for this slot is finished too
            } else {
                showErrorPopup(result.message);
            }
            return;
        }

        // customer: verify, then send a request
        String[] options = { "Send Request", "Close" };
        JTextField contactCheck = new JTextField(15);
        ((AbstractDocument) contactCheck.getDocument()).setDocumentFilter(new LengthFilter(CONTACT_MAX_LEN, true));
        JTextField unitIdCheck = new JTextField(15);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 4);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        panel.add(new JLabel("<html>" + header + "<br>To request a cancellation, enter the details you used "
                + "when renting it.<br>An admin will review your request.</html>"), g);
        g.gridwidth = 1;
        g.gridx = 0; g.gridy = 1; panel.add(new JLabel("Contact Number:"), g);
        g.gridx = 1;              panel.add(contactCheck, g);
        g.gridx = 0; g.gridy = 2; panel.add(new JLabel("Unit ID:"), g);
        g.gridx = 1;              panel.add(unitIdCheck, g);

        int choice = JOptionPane.showOptionDialog(this, panel, "Request Cancellation",
                JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                null, options, options[1]);
        if (choice != 0) return;

        String contact = slot.getCustomerContact() == null ? "" : slot.getCustomerContact().trim();
        String unitId = slot.getUnitId() == null ? "" : slot.getUnitId().trim();
        if (!contact.equals(contactCheck.getText().trim())
                || !unitId.equalsIgnoreCase(unitIdCheck.getText().trim())) {
            showErrorPopup("The details you entered don't match this rental.");
            return;
        }

        ParkingSystem.TransactionResult result =
                system.requestCancellation(getSelectedSection(), slot.getSlotNumber());
        if (result.success) {
            JOptionPane.showMessageDialog(this, result.message,
                    "Request Sent", JOptionPane.INFORMATION_MESSAGE);
        } else {
            showErrorPopup(result.message);
        }
    }

    private void showErrorPopup(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearBookingForm() {
        nameField.setText("");
        contactField.setText("");
        unitField.setText("");
        unitIdField.setText("");
        durationCountField.setText("");
        durationUnitCombo.setSelectedItem(Floor.UNIT_MONTH);
        plateField.setText("");
        carTypeCombo.setSelectedIndex(0);
    }

    private static class LengthFilter extends DocumentFilter {
        private final int maxLength;
        private final boolean digitsOnly;

        LengthFilter(int maxLength, boolean digitsOnly) {
            this.maxLength = maxLength;
            this.digitsOnly = digitsOnly;
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                throws BadLocationException {
            replace(fb, offset, 0, string, attr);
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            if (text == null) {
                super.replace(fb, offset, length, text, attrs);
                return;
            }
            if (digitsOnly) {
                for (int i = 0; i < text.length(); i++) {
                    if (!Character.isDigit(text.charAt(i))) {
                        return; 
                    }
                }
            }
            int newLength = fb.getDocument().getLength() - length + text.length();
            if (newLength <= maxLength) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }

    // Header bar 
    private JPanel makeHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.SURFACE);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER),
                BorderFactory.createEmptyBorder(12, 18, 12, 18)));

        JLabel title = new JLabel("<html><span style='color:#1FB5A3;'>&#9679;</span>&nbsp; Condominium Parking</html>");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        header.add(title, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);

        JLabel roleBadge = new JLabel(role.name());
        roleBadge.setFont(roleBadge.getFont().deriveFont(Font.BOLD, 11f));
        roleBadge.setForeground(Theme.ACCENT);
        roleBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.ACCENT),
                BorderFactory.createEmptyBorder(3, 10, 3, 10)));
        right.add(roleBadge);

        JButton logoutButton = new JButton("Logout");
        Theme.secondary(logoutButton);
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginFrame(system).setVisible(true);
        });
        right.add(logoutButton);

        header.add(right, BorderLayout.EAST);
        return header;
    }

    // Invoice popup 
    private void showInvoice(ParkingSystem.ReportRow r) {
        JDialog dialog = new JDialog(this, "Invoice", true);

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.SURFACE);
        card.setBorder(BorderFactory.createEmptyBorder(24, 30, 24, 30));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(3, 0, 3, 0);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        int row = 0;

        String invoiceNo = String.format("INV-%s-%03d", r.section.replaceAll("\\s+", ""), r.slotNumber);
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
        double rate = r.rentDuration > 0 ? r.amountPaid / r.rentDuration : 0.0;

        JLabel heading = new JLabel("INVOICE");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 24f));
        heading.setForeground(Theme.ACCENT);
        g.gridx = 0; g.gridy = row++; g.gridwidth = 2;
        card.add(heading, g);

        row = addInvoiceLine(card, g, row, "Invoice No.", invoiceNo);
        row = addInvoiceLine(card, g, row, "Date Issued", date);

        row = addInvoiceSection(card, g, row, "BILLED TO");
        row = addInvoiceLine(card, g, row, "Customer", r.customerName);
        row = addInvoiceLine(card, g, row, "Contact", r.customerContact);
        row = addInvoiceLine(card, g, row, "Unit", r.unit);
        row = addInvoiceLine(card, g, row, "Unit ID", r.unitId);

        row = addInvoiceSection(card, g, row, "PARKING DETAILS");
        row = addInvoiceLine(card, g, row, "Section", r.section);
        row = addInvoiceLine(card, g, row, "Slot No.", r.slotNumber + (r.pwd ? " (PWD)" : ""));
        row = addInvoiceLine(card, g, row, "Plate No.", r.plateNo);
        row = addInvoiceLine(card, g, row, "Car Type", r.carType + (r.eCar ? " (E-Car)" : ""));

        row = addInvoiceSection(card, g, row, "RENTAL");
        row = addInvoiceLine(card, g, row, "Rate",
                String.format("Php %,.2f / %s", rate, r.rentDurationUnit.toLowerCase()));
        row = addInvoiceLine(card, g, row, "Duration", r.rentDuration + " " + r.rentDurationUnit + "(s)");
        if (r.pwd) {
            row = addInvoiceLine(card, g, row, "Discount", "PWD rate applied");
        }

        row = addInvoiceSection(card, g, row, "");
        JLabel totalLabel = new JLabel("TOTAL PAID");
        totalLabel.setFont(totalLabel.getFont().deriveFont(Font.BOLD, 15f));
        JLabel totalValue = new JLabel(String.format("Php %,.2f", r.amountPaid), SwingConstants.RIGHT);
        totalValue.setFont(totalValue.getFont().deriveFont(Font.BOLD, 20f));
        totalValue.setForeground(Theme.ACCENT);
        g.gridwidth = 1;
        g.gridx = 0; g.gridy = row; card.add(totalLabel, g);
        g.gridx = 1; g.gridy = row++; card.add(totalValue, g);

        JButton closeButton = new JButton("Close");
        Theme.primary(closeButton);
        closeButton.addActionListener(e -> dialog.dispose());
        g.insets = new Insets(20, 0, 0, 0);
        g.gridx = 0; g.gridy = row; g.gridwidth = 2;
        card.add(closeButton, g);

        dialog.setContentPane(card);
        dialog.getRootPane().setDefaultButton(closeButton);
        dialog.pack();
        dialog.setSize(Math.max(400, dialog.getWidth()), dialog.getHeight());
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private int addInvoiceLine(JPanel card, GridBagConstraints g, int row, String label, String value) {
        JLabel l = new JLabel(label);
        l.setForeground(Theme.MUTED);
        JLabel v = new JLabel(value == null ? "-" : value, SwingConstants.RIGHT);
        g.gridwidth = 1;
        g.gridx = 0; g.gridy = row; card.add(l, g);
        g.gridx = 1; g.gridy = row; card.add(v, g);
        return row + 1;
    }

    private int addInvoiceSection(JPanel card, GridBagConstraints g, int row, String title) {
        Insets saved = g.insets;
        g.gridwidth = 2;
        g.gridx = 0;
        if (!title.isEmpty()) {
            JLabel t = new JLabel(title);
            t.setFont(t.getFont().deriveFont(Font.BOLD, 11f));
            t.setForeground(Theme.ACCENT);
            g.insets = new Insets(16, 0, 2, 0);
            g.gridy = row++;
            card.add(t, g);
        }
        JSeparator sep = new JSeparator();
        g.insets = new Insets(title.isEmpty() ? 16 : 0, 0, 4, 0);
        g.gridy = row++;
        card.add(sep, g);
        g.insets = saved;
        return row;
    }

    // Reports area

    private static final String[] REPORT_COLUMNS = {
            "Section", "Slot #", "PWD", "Customer", "Contact", "Unit", "Unit ID",
            "Plate No.", "Car Type", "E-Car", "Duration", "Amount Paid (Php)"
    };
    private static final int COL_PWD = 2;
    private static final int COL_ECAR = 9;
    private static final int COL_AMOUNT = 11;

    private JPanel makeReportTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Section:"));
        reportSectionCombo = new JComboBox<>();
        reportSectionCombo.addItem(ParkingSystem.ALL_SECTIONS);
        for (Floor f : system.getFloors()) {
            reportSectionCombo.addItem(f.getSection());
        }
        reportSectionCombo.addActionListener(e -> loadReport());
        topPanel.add(reportSectionCombo);

        JButton loadButton = new JButton("Load Report");
        loadButton.addActionListener(e -> loadReport());
        Theme.primary(loadButton);
        topPanel.add(loadButton);

        JLabel hint = new JLabel("   Click a row to open the invoice");
        hint.setForeground(Theme.MUTED);
        topPanel.add(hint);

        panel.add(topPanel, BorderLayout.NORTH);

        reportTableModel = new DefaultTableModel(REPORT_COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        reportTable = new JTable(reportTableModel);
        reportTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        reportTable.setFillsViewportHeight(true);
        reportTable.setRowHeight(28);
        int[] colWidths = { 70, 55, 45, 140, 105, 55, 75, 85, 75, 50, 95, 140 };
        for (int i = 0; i < colWidths.length; i++) {
            reportTable.getColumnModel().getColumn(i).setPreferredWidth(colWidths[i]);
        }
        reportTable.setShowVerticalLines(false);
        reportTable.setGridColor(Theme.BORDER);
        reportTable.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        reportTable.getTableHeader().setReorderingAllowed(false);
        reportTable.getTableHeader().setBackground(Theme.SURFACE_ALT);
        reportTable.getTableHeader().setForeground(Theme.TEXT);

        // click a row then a invoice pops up!
        reportTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = reportTable.rowAtPoint(e.getPoint());
                if (row >= 0 && row < currentReportRows.size()) {
                    showInvoice(currentReportRows.get(row));
                }
            }
        });

        reportTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(column == COL_AMOUNT ? SwingConstants.RIGHT : SwingConstants.LEFT);
                if (!isSelected) {
                    boolean pwd = "Yes".equals(table.getValueAt(row, COL_PWD));
                    boolean eCar = "Yes".equals(table.getValueAt(row, COL_ECAR));
                    if (pwd) {
                        c.setBackground(new Color(0x16, 0x2A, 0x45)); // Dark blue tint
                    } else if (eCar) {
                        c.setBackground(new Color(0x2A, 0x1B, 0x3D)); // Dark purple tint
                    } else {
                        c.setBackground(row % 2 == 0 ? Theme.SURFACE : Theme.SURFACE_ALT);
                    }
                }
                c.setForeground(isSelected ? Color.WHITE : Theme.TEXT);
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return c;
            }
        });

        panel.add(new JScrollPane(reportTable), BorderLayout.CENTER);
        reportSummaryLabel = new JLabel(" ");
        reportSummaryLabel.setForeground(Theme.ACCENT);
        reportSummaryLabel.setBorder(BorderFactory.createEmptyBorder(6, 2, 0, 2));
        panel.add(reportSummaryLabel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadReport() {
        String section = (String) reportSectionCombo.getSelectedItem();

        reportTableModel.setRowCount(0);
        currentReportRows = system.getReportRows(section);
        for (ParkingSystem.ReportRow row : currentReportRows) {
            reportTableModel.addRow(new Object[] {
                    row.section,
                    row.slotNumber,
                    row.pwd ? "Yes" : "No",
                    row.customerName,
                    row.customerContact,
                    row.unit,
                    row.unitId,
                    row.plateNo,
                    row.carType,
                    row.eCar ? "Yes" : "No",
                    row.rentDuration + " " + row.rentDurationUnit + "(s)",
                    String.format("%,.2f", row.amountPaid)
            });
        }

        reportSummaryLabel.setText(String.format(
                "Available: %d   |   Sold: %d   |   Total Revenue: Php %,.2f",
                system.getAvailabilityCount(section),
                system.getSoldCount(section),
                system.getTotalRevenue(section)
        ));
    }

    // Cancel requests area (admin only)

    private static final String[] REQUEST_COLUMNS = {
            "Requested On", "Section", "Slot #", "Customer", "Contact", "Unit", "Unit ID",
            "Plate No.", "Duration", "Amount (Php)"
    };
    private static final int REQUEST_COL_AMOUNT = 9;

    private JPanel makeRequestTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton approveButton = new JButton("Approve & Cancel Rental");
        Theme.primary(approveButton);
        approveButton.addActionListener(e -> approveSelectedRequest());
        topPanel.add(approveButton);

        JButton declineButton = new JButton("Decline Request");
        Theme.secondary(declineButton);
        declineButton.addActionListener(e -> declineSelectedRequest());
        topPanel.add(declineButton);

        JButton refreshButton = new JButton("Refresh");
        Theme.secondary(refreshButton);
        refreshButton.addActionListener(e -> loadCancelRequests(true));
        topPanel.add(refreshButton);

        JLabel hint = new JLabel("   Select a request, then approve or decline it");
        hint.setForeground(Theme.MUTED);
        topPanel.add(hint);
        panel.add(topPanel, BorderLayout.NORTH);

        requestTableModel = new DefaultTableModel(REQUEST_COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        requestTable = new JTable(requestTableModel);
        requestTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        requestTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        requestTable.setFillsViewportHeight(true);
        requestTable.setRowHeight(28);
        int[] colWidths = { 150, 70, 55, 140, 105, 55, 75, 85, 95, 100 };
        for (int i = 0; i < colWidths.length; i++) {
            requestTable.getColumnModel().getColumn(i).setPreferredWidth(colWidths[i]);
        }
        requestTable.setShowVerticalLines(false);
        requestTable.setGridColor(Theme.BORDER);
        requestTable.getTableHeader().setReorderingAllowed(false);
        requestTable.getTableHeader().setBackground(Theme.SURFACE_ALT);
        requestTable.getTableHeader().setForeground(Theme.TEXT);

        requestTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(column == REQUEST_COL_AMOUNT ? SwingConstants.RIGHT : SwingConstants.LEFT);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Theme.SURFACE : Theme.SURFACE_ALT);
                }
                c.setForeground(isSelected ? Color.WHITE : Theme.TEXT);
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return c;
            }
        });

        panel.add(new JScrollPane(requestTable), BorderLayout.CENTER);
        requestSummaryLabel = new JLabel(" ");
        requestSummaryLabel.setForeground(Theme.ACCENT);
        requestSummaryLabel.setBorder(BorderFactory.createEmptyBorder(6, 2, 0, 2));
        panel.add(requestSummaryLabel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadCancelRequests(boolean showErrors) {
        try {
            currentRequests = new ParkingDAO().loadPendingRequests();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (showErrors) showErrorPopup("Could not load the cancel requests.");
            return;
        }

        requestTableModel.setRowCount(0);
        for (ParkingSystem.CancelRequestRow r : currentRequests) {
            requestTableModel.addRow(new Object[] {
                    r.requestedAt,
                    r.section,
                    r.slotNumber,
                    r.customerName,
                    r.customerContact,
                    r.unit,
                    r.unitId,
                    r.plateNo,
                    r.rentDuration + " " + r.rentDurationUnit + "(s)",
                    String.format("%,.2f", r.amountPaid)
            });
        }

        int count = currentRequests.size();
        requestSummaryLabel.setText("Pending Requests: " + count);
        int idx = mainTabs.indexOfComponent(requestPanel);
        if (idx >= 0) {
            mainTabs.setTitleAt(idx, count > 0 ? REQUESTS_TAB_TITLE + " (" + count + ")" : REQUESTS_TAB_TITLE);
        }
    }

    private ParkingSystem.CancelRequestRow getSelectedRequest() {
        int row = requestTable.getSelectedRow();
        if (row < 0 || row >= currentRequests.size()) {
            showErrorPopup("Select a request from the table first.");
            return null;
        }
        return currentRequests.get(row);
    }

    private void approveSelectedRequest() {
        ParkingSystem.CancelRequestRow req = getSelectedRequest();
        if (req == null) return;

        String[] options = { "Approve & Cancel", "Back" };
        int choice = JOptionPane.showOptionDialog(this,
                "Cancel the rental of Slot " + req.slotNumber + " (Section " + req.section + ") for "
                        + req.customerName + "?\nThe slot will become available again.",
                "Approve Request", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                null, options, options[1]);
        if (choice != 0) return;

        ParkingSystem.TransactionResult result =
                system.cancelRental(req.section, req.slotNumber, "ADMIN (request)");
        if (result.success) {
            JOptionPane.showMessageDialog(this, result.message,
                    "Rental Cancelled", JOptionPane.INFORMATION_MESSAGE);
            rebuildSlotGrid();
            loadCancelRequests(false);
        } else {
            showErrorPopup(result.message);
        }
    }

    private void declineSelectedRequest() {
        ParkingSystem.CancelRequestRow req = getSelectedRequest();
        if (req == null) return;

        String[] options = { "Decline Request", "Back" };
        int choice = JOptionPane.showOptionDialog(this,
                "Decline the cancel request for Slot " + req.slotNumber + " (Section " + req.section + ")?\n"
                        + "The rental will stay active.",
                "Decline Request", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, options, options[1]);
        if (choice != 0) return;

        ParkingSystem.TransactionResult result = system.declineCancelRequest(req.requestId, "ADMIN");
        if (result.success) {
            JOptionPane.showMessageDialog(this, result.message,
                    "Request Declined", JOptionPane.INFORMATION_MESSAGE);
        } else {
            showErrorPopup(result.message);
        }
        loadCancelRequests(false);
    }

    private static final String[] CANCEL_COLUMNS = {
            "Cancelled On", "Section", "Slot #", "Customer", "Contact", "Unit", "Unit ID",
            "Plate No.", "Duration", "Amount (Php)", "Cancelled By"
    };
    private static final int CANCEL_COL_AMOUNT = 9;

    private JPanel makeCancellationTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refreshButton = new JButton("Refresh");
        Theme.primary(refreshButton);
        refreshButton.addActionListener(e -> loadCancellations());
        topPanel.add(refreshButton);

        JLabel hint = new JLabel("   Rentals cancelled by an admin (directly or from a customer request), newest first");
        hint.setForeground(Theme.MUTED);
        topPanel.add(hint);
        panel.add(topPanel, BorderLayout.NORTH);

        cancelTableModel = new DefaultTableModel(CANCEL_COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable cancelTable = new JTable(cancelTableModel);
        cancelTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        cancelTable.setFillsViewportHeight(true);
        cancelTable.setRowHeight(28);
        int[] colWidths = { 150, 70, 55, 140, 105, 55, 75, 85, 95, 100, 130 };
        for (int i = 0; i < colWidths.length; i++) {
            cancelTable.getColumnModel().getColumn(i).setPreferredWidth(colWidths[i]);
        }
        cancelTable.setShowVerticalLines(false);
        cancelTable.setGridColor(Theme.BORDER);
        cancelTable.getTableHeader().setReorderingAllowed(false);
        cancelTable.getTableHeader().setBackground(Theme.SURFACE_ALT);
        cancelTable.getTableHeader().setForeground(Theme.TEXT);

        cancelTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(column == CANCEL_COL_AMOUNT ? SwingConstants.RIGHT : SwingConstants.LEFT);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Theme.SURFACE : Theme.SURFACE_ALT);
                }
                c.setForeground(isSelected ? Color.WHITE : Theme.TEXT);
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return c;
            }
        });

        panel.add(new JScrollPane(cancelTable), BorderLayout.CENTER);
        cancelSummaryLabel = new JLabel(" ");
        cancelSummaryLabel.setForeground(Theme.ACCENT);
        cancelSummaryLabel.setBorder(BorderFactory.createEmptyBorder(6, 2, 0, 2));
        panel.add(cancelSummaryLabel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadCancellations() {
        List<ParkingSystem.CancellationRow> rows;
        try {
            rows = new ParkingDAO().loadCancellations();
        } catch (Exception ex) {
            ex.printStackTrace();
            showErrorPopup("Could not load the cancellation log.");
            return;
        }

        cancelTableModel.setRowCount(0);
        double total = 0.0;
        for (ParkingSystem.CancellationRow r : rows) {
            cancelTableModel.addRow(new Object[] {
                    r.cancelledAt,
                    r.section,
                    r.slotNumber,
                    r.customerName,
                    r.customerContact,
                    r.unit,
                    r.unitId,
                    r.plateNo,
                    r.rentDuration + " " + r.rentDurationUnit + "(s)",
                    String.format("%,.2f", r.amountPaid),
                    r.cancelledBy
            });
            total += r.amountPaid;
        }
        cancelSummaryLabel.setText(String.format(
                "Total Cancellations: %d   |   Amount of Cancelled Rentals: Php %,.2f", rows.size(), total));
    }

    private static class CarIcon implements Icon {
        private static final int W = 32, H = 18;

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color cut = c.getBackground();

            g2.setColor(Color.BLACK);
            // roof
            g2.fillPolygon(new int[] { x + 8, x + 11, x + 21, x + 24 },
                           new int[] { y + 8, y + 1, y + 1, y + 8 }, 4);
            // body
            g2.fillRoundRect(x, y + 7, W, 7, 5, 5);

            // windows
            g2.setColor(cut);
            g2.fillPolygon(new int[] { x + 10, x + 12, x + 15, x + 15 },
                           new int[] { y + 7, y + 3, y + 3, y + 7 }, 4);
            g2.fillPolygon(new int[] { x + 17, x + 17, x + 20, x + 22 },
                           new int[] { y + 7, y + 3, y + 3, y + 7 }, 4);

            // wheels
            g2.setColor(Color.BLACK);
            g2.fillOval(x + 5, y + 10, 8, 8);
            g2.fillOval(x + 19, y + 10, 8, 8);
            g2.setColor(cut);
            g2.fillOval(x + 7, y + 12, 4, 4);
            g2.fillOval(x + 21, y + 12, 4, 4);

            g2.dispose();
        }

        @Override public int getIconWidth()  { return W; }
        @Override public int getIconHeight() { return H; }
    }

    public static void main(String[] args) {
        Theme.apply();
        ParkingSystem system;
        try {
            // LOAD FROM DATABASE
            ParkingDAO dao = new ParkingDAO();
            system = dao.loadFloors();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database connection failed! Make sure MySQL is running.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Stop the app if the DB isn't connected
        }

        SwingUtilities.invokeLater(() -> {
            new LoginFrame(system).setVisible(true);
        });
    }
}