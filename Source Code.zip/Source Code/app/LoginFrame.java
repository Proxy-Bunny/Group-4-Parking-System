package app;

import lib.ParkingSystem;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final ParkingSystem system;
    private JTextField idField;
    private JPasswordField passwordField;

    public LoginFrame(ParkingSystem system) {
        super("Condominium Parking Rental System - Login");
        this.system = system;

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(28, 36, 28, 36));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Please log in", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        title.setForeground(Theme.ACCENT);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        form.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        form.add(new JLabel("ID:"), gbc);
        idField = new JTextField(15);
        gbc.gridx = 1;
        form.add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        form.add(new JLabel("Password:"), gbc);
        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        form.add(passwordField, gbc);

        JButton loginButton = new JButton("Login");
        Theme.primary(loginButton);
        loginButton.addActionListener(e -> attemptLogin());
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        form.add(loginButton, gbc);

        // pressing Enter also logs in
        getRootPane().setDefaultButton(loginButton);

        setContentPane(form);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    private void attemptLogin() {
        String id = idField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (id.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your ID and password.",
                    "Login", JOptionPane.WARNING_MESSAGE);
            return;
        }

        ParkingSystem.Role role = system.login(id, password);
        if (role == null) {
            JOptionPane.showMessageDialog(this, "Invalid ID or password.",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
            return;
        }

        dispose(); // close login window
        new Frontend(system, role).setVisible(true);
    }
}